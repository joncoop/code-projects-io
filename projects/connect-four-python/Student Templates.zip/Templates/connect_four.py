import functions


# Board size
NUM_ROWS = 6
NUM_COLS = 7

# Win condition
STREAK_LENGTH = 4

# Token symbols
TOKENS = {
    0: "-",  # Empty
    1: "X",  # Player 1
    2: "O"   # Player 2
}


def show_start_screen():
    pass


def show_end_screen():
    pass


def play_again():
    """ Asks the player if they want to play again """
    while True:
        answer = input("Would you like to play again? (y/n)? ")
        answer = answer.lower().strip()
        
        if answer in ['y', 'yes']:
            return True
        elif answer in ['n', 'no']:
            return False


def display_board(board):
    """ Displays the board nicely with token symbols and numbered columns. """
    pass


def get_drop_column(board, player):
    """ Asks the player for a column to drop. Returns column if selcetion is valid, reasks otherwise. """
    pass


def play():
    """ main game logic """
    pass


def main():
    show_start_screen()

    running = True

    while running:
        play()
        running = play_again()

    show_end_screen()


if  __name__ == "__main__":
    main()
