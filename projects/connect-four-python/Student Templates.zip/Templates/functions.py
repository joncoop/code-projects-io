"""
This module contains functions for managing data in a Connect Four game.
"""

# Functions for Assignment 1 (Manipulating the Game Board)

def make_board(num_rows=7, num_cols=6):
    board = []

    for _ in range(num_rows):
        row = [0] * num_cols
        board.append(row)

    return board


def row_is_valid(board, row):
    pass


def column_is_valid(board, column):
    pass


def location_is_valid(board, row, column):
    pass


def place_token(board, token, row, column):
    pass


def location_empty(board, row, column):
    pass


def column_available(board, column):
    pass


def drop_token(board, column, token):
    pass



# Functions for Assignment 2 (Determing a Result)

def get_row(board, row):
    pass


def get_column(board, column):
    pass


def get_left_diagonal(board, row, column):
    pass


def get_right_diagonal(board, row, column):
    pass


def has_streak(sequence, token, length):
    pass


def check_win(board, row, column, length=4):
    pass


def board_full(board):
   pass
