import functions


def print_2d_array(array):
    for row in array:
        print(row)


def do_tests():
    print('Make board')
    board = functions.make_board()
    print_2d_array(board)
    print()

    print('Place_token')
    functions.place_token(board, 2, 5, 1)
    print_2d_array(board)
    print()

    functions.place_token(board, 1, 4, 1)
    functions.place_token(board, 2, 3, 1)
    functions.place_token(board, 1, 2, 1)
    functions.place_token(board, 2, 5, 2)
    functions.place_token(board, 1, 4, 2)
    functions.place_token(board, 2, 3, 2)
    functions.place_token(board, 1, 2, 2)
    functions.place_token(board, 2, 1, 2)
    functions.place_token(board, 1, 0, 2)
    print_2d_array(board)
    print()
    
    print('Location empty')
    print(functions.location_empty(board, 0, 0))
    print(functions.location_empty(board, 3, 1))
    print()

    print('Column available')    
    print(functions.column_available(board, 0))
    print(functions.column_available(board, 1))
    print(functions.column_available(board, 2))
    print()

    print('Drop token')    
    print(functions.drop_token(board, 0, 2))
    print(functions.drop_token(board, 1, 1))
    print_2d_array(board)
    print()


if __name__ == '__main__':
    do_tests()
